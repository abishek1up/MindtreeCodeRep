import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import {BaseService} from './shared/Base.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { from } from 'rxjs';
import {HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';
import {HttpModule,Http,Response,Headers,RequestOptions,RequestMethod} from '@angular/http';
import { UserComponent } from './user/user.component';
import { ErrorComponent } from './error/error.component';
import { AuthService } from "src/app/shared/auth.service";
import { AuthGuard } from "src/app/shared/auth.guard";
import {TokenInterceptorService} from './shared/token-interceptor.service';
import { Router } from "@angular/router";
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    UserComponent,
    ErrorComponent,
  
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpModule
    
  ],
  providers: [AuthService,AuthGuard,
  {
    provide:HTTP_INTERCEPTORS,
    useClass:TokenInterceptorService,
    multi:true
  }],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(private router:Router)
  {this.router.navigateByUrl('Home');}
 }
