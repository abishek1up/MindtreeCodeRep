import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BoolData } from '../Shared/BoolData.model';
import {BaseService} from '../shared/Base.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private base:BaseService,private router : Router) { }
flag:Boolean;
  ngOnInit() {
  }

  resetform(form?:NgForm)
  {if(form!=null)
    form.reset();   
 }

  OnSubmit(form:NgForm)
  {  
    // var str1:string=form.value.Username; 
    // var str3:string=form.value.Password; 
    // var str2:string="$"; 
    // str1 = str1.concat(str2); 
    // str1 = str1.concat(str3);  
    // console.log(str1);
    // this.base.validateUser(str1);  
    if(form.value.Username=="A")
      {
            this.FixUsertoken();
            this.router.navigateByUrl('/User');
          
          }
          else 
          {
           this.router.navigateByUrl('/Login'); 
          }
      }

  FixUsertoken()
  {
      localStorage.setItem('userToken',"2345678976543");
  }

}
