export class BoolData {
    isValid:Boolean;
    tokenString:string;
   }