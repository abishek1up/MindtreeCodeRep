import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { from } from 'rxjs';
import {map} from 'rxjs/operators';
import {HttpModule,Http,Response,Headers,RequestOptions,RequestMethod} from '@angular/http';
import { BoolData } from "src/app/shared/BoolData.model";
import { Router } from "@angular/router";

@Injectable({
  providedIn: 'root'
})
export class BaseService {
  booldataobj:BoolData;
  isValid:Boolean;
  constructor(private http:Http,private router:Router)
  { }
  validateUser(str:string)
  { 
  return this.http.get('http://localhost:58419/api/BoolDatas/'+str).pipe(map((data:Response)=>{
    return data.json() as BoolData;
   })).toPromise().then(x=>{
     this.booldataobj=x;
    this.isValid=this.booldataobj.isValid;
  if(this.isValid)
    {
      this.FixUsertoken();
      this.router.navigateByUrl('/User');
    
    }
    else 
    {
     this.router.navigateByUrl('/Login'); 
    }})
 }
 FixUsertoken()
 {
     localStorage.setItem('userToken',this.booldataobj.tokenString);
 }
}
