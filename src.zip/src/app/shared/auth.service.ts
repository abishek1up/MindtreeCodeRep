import { Injectable } from '@angular/core';
import { Http } from "@angular/http";
import { BaseService } from "src/app/shared/base.service";
import { Router } from "@angular/router";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private base:BaseService,private http:Http,private router:Router) { }
  loggedIn()
  {
    if (localStorage.getItem('userToken')!=null)
return true;
    else
      return false;
  }
  getToken()
  {
    return localStorage.getItem('userToken')
  }
  logoutUser()
  {
    localStorage.removeItem('userToken')
    this.router.navigate(['Home'])
  }

}
