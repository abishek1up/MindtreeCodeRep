import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from "src/app/shared/auth.service";
import { Router } from "@angular/router";


@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private authserv: AuthService, private router: Router)
  {}
  canActivate():boolean{
    if(this.authserv.loggedIn())
      {return true;
      }
      else
      {
        this.router.navigate(['/Login']);
        return false;
      }
  }
  }
 
