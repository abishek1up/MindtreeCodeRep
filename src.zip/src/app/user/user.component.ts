import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { BaseService } from "src/app/shared/base.service";

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private base:BaseService,private router : Router) { }

  ngOnInit() {
  }
  
Logout() {
    localStorage.removeItem('userToken');
    this.router.navigate(['/Login']);
  }
}
