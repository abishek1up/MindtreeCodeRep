import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from "src/app/login/login.component";
import { HomeComponent } from "src/app/home/home.component";
import { UserComponent } from "src/app/user/user.component";
import { AuthGuard } from "src/app/shared/auth.guard";

const routes: Routes = [
  { path:'Home',component: HomeComponent },
{path:'Login',component:LoginComponent},
{path:'User',component:UserComponent,canActivate:[AuthGuard]},
{path:'Error',component:UserComponent}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
