using FindMyRoomWEbApi.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FindMyRoomWEbApi.DAL
{
  public class AdminAccessor
  {
    private readonly FindMyRoom_DatabaseEntities db = new FindMyRoom_DatabaseEntities();
    public List<Admin_ListUnVerifiedProperties_Result> Get_UnverifiedProperties()
    {
      try
      {
        return db.Admin_ListUnVerifiedProperties().ToList();
      }
      catch (Exception exc)
      {

        throw exc;
      }
    }

    public List<Admin_ListVerifiedProperties_Result> GetVerifiedProperties()
    {
      try
      {
        return db.Admin_ListVerifiedProperties().ToList();
      }
      catch (Exception exc)
      {

        throw exc;
      }
    }

    public List<Admin_OwnerDetails_Result> Getowners()
    {
      return db.Admin_OwnerDetails().ToList();
    }

    public List<Admin_UsersList_Result> Getusers()
    {
      return db.Admin_UsersList().ToList();
    }

    public List<FeedbackTable> GetFeedbacks()
    {
      return db.FeedbackTables.ToList();
    }

    public bool VerifyProperty(int? id)
    {
      int changes = 0;
      try
      {
        changes = db.Admin_VerifyProperty(id);
      }
      catch (Exception)
      {

        throw new Exception("");
      }
      if (changes > 0)
      {
        return true;
      }
      else
      {
        return false;
      }
    }

    public Property findProperty(int propertyID)
    {
      return db.Properties.Find(propertyID);
    }








  }
}
