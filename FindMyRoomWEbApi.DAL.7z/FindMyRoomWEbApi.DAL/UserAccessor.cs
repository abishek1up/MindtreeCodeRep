using FindMyRoomWEbApi.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FindMyRoomWEbApi.DAL
{
  public class UserAccessor
  {
    private FindMyRoom_DatabaseEntities db = new FindMyRoom_DatabaseEntities();

    public async Task<int> SaveUserDetails(User user)
    {
      int result = 0;
      try
      {
        //storing the loyality points
        if (user.Referral_code == null)
          user.LoyalityPoint = 0;
        else
        {
          User u = (from t in db.Users
                    where t.Referral_code == user.Referral_code
                    select t).SingleOrDefault();
          if (u != null)
          {
            u.LoyalityPoint += 50;
            user.LoyalityPoint = 50;
            try
            {
              result = await db.SaveChangesAsync();
            }
            catch (Exception e)
            {
              Console.WriteLine(e.Message);
            }
          }
          else user.LoyalityPoint = 0;

        }


        user.Referral_code = await GenerateUniqueRefferal();

        try
        {
          db.Users.Add(user);
          await db.SaveChangesAsync();
        }
        catch (Exception ex)
        {
          Console.WriteLine(ex.Message);
        }
        return result;
      }


      catch (Exception e)
      {
        throw new Exception("Something went wrong!!");
      }

    }

    public async Task<int> verifyEmailD(string mail)
    {
      try
      {

        int result = (from t in db.Users where t.email == mail select t).Count();
        if (result == 0)
          return 0;
        else
          return 1;

      }
      catch (Exception exc)
      {
        throw new Exception("My Exception");
      }


    }

    public async Task<int> verifyPhoneD(string phone)
    {
      try
      {

        int result = (from t in db.Users
                      where t.Phone_number == phone
                      select t).Count();
        if (result == 0)
          return 0;
        else
          return 1;

      }
      catch (Exception exc)
      {
        throw new Exception("Exception Occured !");
      }

    }


    //function to check whether the refferal code entered exists or not 
    public async Task<string> CheckRefferalCode(string r_code)
    {

      try
      {
        User u = (from t in db.Users
                  where t.Referral_code == r_code
                  select t).SingleOrDefault();
        if (u != null)
          return "1";
        else return "0";
      }
      catch (Exception)
      {

        throw new Exception("Exception Occurred");
      }
    }


    //function for refferal code generation
    public async Task<String> Refcode()
    {
      try
      {
        var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789FINDMYROOM";
        var stringChars = new char[8];
        var random = new Random();
        for (int i = 0; i < stringChars.Length; i++)
        {
          stringChars[i] = chars[random.Next(chars.Length)];
        }
        String finalString = new String(stringChars);
        return finalString;
      }
      catch (Exception exc)
      {

        throw;
      }
    }
    //generating unique refferal code for the user
    public async Task<string> GenerateUniqueRefferal()
    {
      int result = 1;
      string code;
      do
      {
        code = await Refcode();
        result = (from t in db.Users
                  where t.Referral_code == code
                  select t).Count();
      } while (result != 0);
      return code;
    }

    public async Task<int> verifyMailDAL(string mail)
    {
      int result = (from t in db.Users
                    where t.email == mail
                    select t).Count();

      if (result == 1)
      {
        return 1;
      }
      return 0;
    }
    public async Task<int> updatePasswordDAL(string mail, string newPassword)
    {
      int result = 0;
      User query = (from us in db.Users
                    where us.email == mail
                    select us).SingleOrDefault();
      query.password = newPassword;
      try
      {
        result = await db.SaveChangesAsync();
      }
      catch (Exception e)
      {
        throw new Exception(e.Message);
      }
      return result;
    }


    public async Task<string> confirmPasswordDAL(string mail)
    {

      try
      {
        int result = 0;
        User query = (from us in db.Users
                      where us.email == mail
                      select us).SingleOrDefault();
        return query.password;
      }
      catch (Exception exc)
      {

        throw exc;
      }
    }



    public List<User> LoginCheckDataAccess()
    {
      List<User> UserDetails = new List<User>();
      try
      {
        UserDetails = db.Users.ToList<User>();
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
      }
      return UserDetails;
    }


    public bool UserExists(int id)
    {
      return db.Users.Count(e => e.UserId == id) > 0;
    }


    public User getUserbyId(int id)
    {
      User user = new User();

      try
      {
        user = db.Users.Find(id);
        return user;
      }
      catch (Exception exc)
      {
        var x = exc.Message;
        return user;
      }

    }


  }
}
