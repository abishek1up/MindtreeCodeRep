using FindMyRoomWEbApi.Entity;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FindMyRoomWEbApi.DAL
{
  public class PropertyAccessor
  {

    private FindMyRoom_DatabaseEntities db = new FindMyRoom_DatabaseEntities();

    public List<Location> GetLocation()
    {

      try
      {
        return db.Locations.ToList<Location>();
      }
      catch (Exception exc)
      {

        throw exc;
      }
    }

    public List<City> GetCities()
    {

      List<City> citydetails = new List<City>();

      try
      {

        citydetails = db.Cities.ToList<City>();

      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
      }

      return citydetails;
    }


    public List<List_of_Properties_Result> GetPropertyList(string city)
    {
      return db.List_of_Properties(city).ToList();

    }
    public ObjectResult<User_PropertyDetails_Result> FindPropertydetails(int Propid)
    {
      return db.User_PropertyDetails(Propid);

    }

    public async Task<int> PostPropertyDAL(PropertyRegistration propertyRegistration)
    {

      try
      {
        propertyRegistration.Posted_date = System.DateTime.Now.Date;
        int result = db.INSERT_PROPERTY(propertyRegistration.Property_Name, propertyRegistration.Address, propertyRegistration.Advance, propertyRegistration.Amenities, propertyRegistration.Carpet_area, propertyRegistration.Construction_Age, propertyRegistration.isVerified, propertyRegistration.LocationId, propertyRegistration.no_of_floors, propertyRegistration.Posted_date, propertyRegistration.Price, propertyRegistration.Property_description, propertyRegistration.Type, propertyRegistration.UserId, propertyRegistration.Occupancy, propertyRegistration.AvailableFor, propertyRegistration.Bachelor_friendly, propertyRegistration.Built_up_area, propertyRegistration.Deal_type, propertyRegistration.Flat_type, propertyRegistration.Flooring, propertyRegistration.Furnishing, propertyRegistration.Possesion_ready, propertyRegistration.water_source, propertyRegistration.AC, propertyRegistration.Bed, propertyRegistration.Community_hall, propertyRegistration.Gas_conn, propertyRegistration.Lift, propertyRegistration.Parking, propertyRegistration.Refridgerator, propertyRegistration.Sofa, propertyRegistration.swimming_pool, propertyRegistration.TV);
        return result;
      }

      catch (Exception exc)
      {

        throw exc;
      }

    }

    public async Task<int> UpdatePropertyDAL(PropertyUpdation propertyUpdation)
    {
      try
      {
        int result = db.Update_PROPERTY(propertyUpdation.PropertyID, propertyUpdation.Property_Name, propertyUpdation.Address, propertyUpdation.Advance, propertyUpdation.Amenities, propertyUpdation.Carpet_area, propertyUpdation.Construction_Age, propertyUpdation.isVerified, propertyUpdation.LocationId, propertyUpdation.no_of_floors, propertyUpdation.Posted_date, propertyUpdation.Price, propertyUpdation.Property_description, propertyUpdation.Type, propertyUpdation.UserId, propertyUpdation.Occupancy, propertyUpdation.AvailableFor, propertyUpdation.Bachelor_friendly, propertyUpdation.Built_up_area, propertyUpdation.Deal_type, propertyUpdation.Flat_type, propertyUpdation.Flooring, propertyUpdation.Furnishing, propertyUpdation.Possesion_ready, propertyUpdation.water_source, propertyUpdation.AC, propertyUpdation.Bed, propertyUpdation.Community_hall, propertyUpdation.Gas_conn, propertyUpdation.Lift, propertyUpdation.Parking, propertyUpdation.Refridgerator, propertyUpdation.Sofa, propertyUpdation.swimming_pool, propertyUpdation.TV);
        return result;
      }
      catch (Exception exc)
      {

        throw exc;
      }

    }

    public List<User_PropertyDetails_Result> GetPropertyDAL(int PropId)
    {
      try
      {
        List<User_PropertyDetails_Result> listprops = db.User_PropertyDetails(PropId).ToList<User_PropertyDetails_Result>();
        return listprops;
      }
      catch (Exception exc)
      {

        throw exc;
      }
    }



    public List<List_of_Properties_By_User_Result> GetListOfPropertiesByUser (int PropId)
    {
      try
      {
        List<List_of_Properties_By_User_Result> listprops = db.List_of_Properties_By_User(PropId).ToList<List_of_Properties_By_User_Result>();
        return listprops;
      }
      catch (Exception exc)
      {

        throw exc;
      }
    }





  }
}
