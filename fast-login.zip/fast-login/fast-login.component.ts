import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';
import { Form } from "@angular/forms";
import { NgForm } from '@angular/forms';
import { inject, NgModule } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { Router } from "@angular/router";
import { BaseService } from "src/app/home/shared/base.service";
import { FormGroup } from "@angular/forms";
import { FormBuilder } from "@angular/forms";
import { FormControl } from "@angular/forms";
import { Validators } from "@angular/forms";
import { LoginAuthenticationService } from "src/app/home/shared/login-authentication.service";
import swal from 'sweetalert2';
@Component({
  selector: 'app-fast-login',
  templateUrl: './fast-login.component.html',
  styleUrls: ['./fast-login.component.css']
})
export class FastLoginComponent implements OnInit {
  forgotPasswordForm: FormGroup;    
  email:string='';  
  rege=/\S+@\S+\.\S+/;
  result:number; 
  flag: Boolean;
  Pasword: string;
  emailID: string;
  userName: string;
  Admintoken:string="cdd654667r4fd3455678hgfd";
  updateResult:boolean = true;
  loginForm: FormGroup;  
  password:string=''; 
  constructor(public authServ:LoginAuthenticationService,public dialog: MatDialog,private fb: FormBuilder,public dialogRef:MatDialogRef<FastLoginComponent>,public base: BaseService, private router: Router,private toastr: ToastrService) 
  {this.loginForm = fb.group({  
    'email' : new FormControl('', [
      Validators.required,
      Validators.pattern(this.rege)]),
  //  'password' : [null, Validators.required,Validators.minLength(9),Validators.maxLength(16)],   
    'password' : new FormControl('', [
      Validators.required,
      Validators.required,Validators.minLength(9),Validators.maxLength(16)]),
    // 'email':[null, Validators.compose([Validators.required,Validators.email])]
  }); } 
  resetform(form?: NgForm) {
    if (form != null)
      form.reset();
  }
  OnSubmit(form: NgForm) {
    
    if (form.value.email == "admin@mid.com" && form.value.password == "admin12345")   
    {
      this.dialogRef.close();
      localStorage.setItem('adminToken',"cdfv234567897654324567");
    }
    else
    {
      var concatStr: string;
      concatStr = form.value.email.concat(":");
      concatStr = concatStr.concat(form.value.password);
      this.base.validateUserFast(concatStr);
      const swal = require('sweetalert2')
      let timerInterval
      swal({
        title: 'Verifying..',
        timer: 2000,
        onOpen: () => {
          swal.showLoading()
          timerInterval = setInterval(() => {
            swal.getContent().querySelector('strong')
              .textContent = swal.getTimerLeft()
          }, 100)
        },
        onClose: () => {
          if(this.authServ.loggedIn())
            {
             this.dialogRef.close();
             swal({
              type: 'success',
              title: 'Successfuly Logged In',
              showConfirmButton: false,
              timer: 1500
            })
            }
          clearInterval(timerInterval)
        }
      }).then((result) => {
        if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.timer
        ) {
          console.log('I was closed by the timer')
        }
      })
     }
  }
  ngOnInit() {
  }

  

}
