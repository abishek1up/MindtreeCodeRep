import { MatButtonModule } from '@angular/material';
import { AdminHomeIndexComponent } from 'src/app/admin/admin-home-index/admin-home-index.component';
import { LoginAuthenticationService } from './home/shared/login-authentication.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeModule} from './home/home.module'
import {HomeIndexComponent} from './home/home-index/home-index.component'
import { AdminModule } from "./admin/admin.module";
import { LoginComponent } from 'src/app/home/login/login.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { LoginAuthenticationGuard } from "src/app/home/shared/login-authentication.guard";
import { Router } from "@angular/router";
import {HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';
import {HttpModule,Http,Response,Headers,RequestOptions,RequestMethod} from '@angular/http';
import { FormsModule } from "@angular/forms";
import { ReactiveFormsModule } from "@angular/forms";
import { ToastrModule } from 'ngx-toastr';
import {FormControl, FormGroupDirective, NgForm, Validators} from '@angular/forms';
import { FormBuilder, FormGroup} from '@angular/forms';
import { MatIconRegistry } from "@angular/material/icon";
import { DomSanitizer } from "@angular/platform-browser";
import { Form } from "@angular/forms";
import 'hammerjs';
import { ForgetDialogComponent} from "src/app/home/login/forget-dialog/forget-dialog.component";
import {      
  MatMenuModule,MatDialogModule,     
  MatToolbarModule,      
  MatIconModule,      
  MatCardModule,      
  MatFormFieldModule,      
  MatInputModule,      
  MatDatepickerModule,      
  MatDatepicker,      
  MatNativeDateModule,      
  MatRadioModule,      
  MatSelectModule,      
  MatOptionModule,      
  MatSlideToggleModule,ErrorStateMatcher,ShowOnDirtyErrorStateMatcher      
} from '@angular/material';  

@NgModule({
  
  declarations: [
    AppComponent,ForgetDialogComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ToastrModule.forRoot({
      timeOut: 700,
      positionClass: 'toast-bottom-right',
      preventDuplicates: true,
      maxOpened:1
      }),MatButtonModule,      
          MatMenuModule,      
          MatToolbarModule,     
          MatIconModule,      
          MatCardModule,      
          BrowserAnimationsModule,      
          MatFormFieldModule,      
          MatInputModule,      
          MatDatepickerModule,      
          MatNativeDateModule,      
          MatRadioModule,      
          MatSelectModule,      
          MatOptionModule,MatDialogModule,    
          MatSlideToggleModule,HttpModule,HttpClientModule, ReactiveFormsModule, BrowserAnimationsModule],
        exports:[      
          MatButtonModule,      
          MatMenuModule,      
          MatToolbarModule,      
          MatIconModule,      
          MatCardModule,      
          BrowserAnimationsModule,      
          MatFormFieldModule,MatDialogModule,      
          MatInputModule,      
          MatDatepickerModule,      
          MatNativeDateModule,      
          MatRadioModule,      
          MatSelectModule,      
          MatOptionModule,      
          MatSlideToggleModule,
    FormsModule,HttpModule,HttpClientModule, ReactiveFormsModule, BrowserAnimationsModule
  ],
  entryComponents:[ForgetDialogComponent],
  providers: [LoginAuthenticationService,LoginAuthenticationGuard],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(private router:Router) {}
}
 
