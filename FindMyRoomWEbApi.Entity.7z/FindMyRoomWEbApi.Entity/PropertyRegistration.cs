using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FindMyRoomWEbApi.Entity
{
    public class PropertyRegistration
    {
        public Nullable<int> PropertyID { get; set; }

        public string Property_Name { get; set; }
        public bool Amenities { get; set; }
        public int Carpet_area { get; set; }
        public  System.DateTime Posted_date { get; set; }
        public bool isVerified{ get; set; }
        public string city { get; set; }
        public string Type { get; set; }
        public int LocationId { get; set; }
        public int Built_up_area { get; set; }
        public int Construction_Age { get; set; }
        public int no_of_floors { get; set; }
        public string Flooring { get; set; }
        public string water_source { get; set; }
        public string Flat_type { get; set; }
        public bool Sofa { get; set; }
        public string Property_description { get; set; }
        public string Address { get; set; }
        public bool Furnishing { get; set; }
        public string Deal_type { get; set; }
        public bool Possesion_ready { get; set; }
        public bool Bachelor_friendly { get; set; }
        public bool TV { get; set; }
        public bool Refridgerator { get; set; }
        public bool AC { get; set; }
        public bool Bed{ get; set; }
        public bool Gas_conn { get; set; }
        public bool swimming_pool{ get; set; }
        public bool Community_hall { get; set; }
        public bool Lift{ get; set; }
        public bool Parking { get; set; }
        public string additionalTextArea { get; set; }
        public int Advance{ get; set; }
        public int Price{ get; set; }
        public int Occupancy { get; set; }
        public string AvailableFor { get; set; }
        public int UserId { get; set; }
    }
}
