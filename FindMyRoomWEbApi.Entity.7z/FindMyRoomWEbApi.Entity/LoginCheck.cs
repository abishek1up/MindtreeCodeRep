using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace FindMyRoomWEbApi.Entity
{
 

    
        public class LoginCheck
        {
            [Key]
            public bool isValid { get; set; }
            public string tokenString { get; set; }
            public string userEmailID { get; set; }
            public int userID { get; set; }
            public string userName { get; set; }
        }
   

}
