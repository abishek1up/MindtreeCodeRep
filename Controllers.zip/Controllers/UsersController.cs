using System;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using FindMyRoomWEbApi.Entity;
using FindMyRoomWEbApi.BAL;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Net;
using System.Linq;

namespace FindMyRoomWEbApi.Controllers
{
  public class UsersController : ApiController
  {

    private readonly UserManager userManager = new UserManager();
    private readonly FindMyRoom_DatabaseEntities db = new FindMyRoom_DatabaseEntities();


    // Get userdetails by userid
    [HttpGet]
    [Route("api/Users/GetUser")]
    public IHttpActionResult GetUser(int userID)
    {
      return Ok(userManager.GetUserById(userID));
    }


    // posting user

    [HttpPost]
    [Route("api/Users/PostUser/")]
    [ResponseType(typeof(User))]
    public async Task<IHttpActionResult> PostUser(User user)
    {
      try
      {
        return Ok(await userManager.SaveUserDetails(user));
      }
      catch (Exception e)
      {
        return BadRequest();
      }
    }

    // checking the credentials for login
    [HttpGet]
    public async Task<IHttpActionResult> LoginCheck(String id)
    {
      try
      {
        LoginCheck U = userManager.LoginCheckBusinessLogic(id);
        return Ok(U);
      }
      catch (Exception)
      {

        return BadRequest();
      }
    }

    [HttpGet]
    [Route("api/Users/IdbyEmail")]
    public async Task<IHttpActionResult> GetUserIdbyEmail(string email)
    {
      try
      {
        User user = db.Users.FirstOrDefault(x => x.email == email);
        return Ok(user.UserId);
      }
      catch (Exception)
      {

        return BadRequest();
      }
    }


    // verify existing email
    [System.Web.Http.HttpGet]
    [System.Web.Http.Route("api/Users/VerifyEmail")]
    public async Task<IHttpActionResult> VerifyEmail(string email)
    {
      try
      {
        return Ok(await userManager.verifyEmailB(email));
      }
      catch (Exception)
      {

        return BadRequest();
      }
    }


    // verify existing phone number
    [System.Web.Http.HttpGet]
    [System.Web.Http.Route("api/Users/VerifyPhone/")]
    public async Task<IHttpActionResult> VerifyPhone(string phone)
    {
      try
      {
        return Ok(await userManager.verifyPhoneB(phone));
      }
      catch (Exception)
      {

        return BadRequest();
      }
    }


    // verify existing referal codes
    [System.Web.Http.HttpGet]
    [System.Web.Http.Route("api/Users/CheckRefferalCode/")]
    public async Task<IHttpActionResult> CheckRefferalCode(string r_code)     // Check Referal Code
    {
      try
      {
        return Ok(await userManager.CheckRefferalCode(r_code));
      }
      catch (Exception)
      {

        return BadRequest();
      }
    }


    [HttpGet]
    [Route("api/Users/verifyMail/")]          // Verifying Email Address

    public async Task<IHttpActionResult> verifyMail(string mail)
    {

      try
      {
        return Ok(await userManager.verifyMailBAL(mail));
      }
      catch (Exception)
      {

        return BadRequest();
      }

    }



    [HttpGet]
    [Route("api/Users/generateOTP")]
    public async Task<IHttpActionResult> generateOTP(string mail)  // OTP Generation
    {

      return Ok(await userManager.generateOTPBAL(mail));
    }



    [HttpGet]
    [Route("api/Users/updatePassword")]
    public async Task<IHttpActionResult> updatePassword(string parameter)     // Update password
    {
      string[] values = parameter.Split(':');
      try
      {
        return Ok(await userManager.updatePasswordBAL(values[0], values[1]));
      }
      catch (Exception)
      {
        return BadRequest();
      }

    }



    [HttpGet]
    [Route("api/Users/confirmPassword")]
    public async Task<IHttpActionResult> confirmPassword(string parameter)   // confirmation of password
    {
      try
      {
        string[] values = parameter.Split(':');
        return Ok(await userManager.confirmPasswordBAL(values[0], values[1]));
      }
      catch (Exception)
      {

        return BadRequest();
      }
    }




    [HttpPut]
    [ResponseType(typeof(void))]
    [Route("api/Users/PutUser")]
    public async Task<IHttpActionResult> PutUser(User user)   // Update Users Data
    {
      if (!ModelState.IsValid)
      {
        return BadRequest(ModelState);
      }
      db.Entry(user).State = EntityState.Modified;
      try
      {
        await db.SaveChangesAsync();
      }
      catch (DbUpdateConcurrencyException)
      {
        if (!userManager.UserExists(user.UserId))
        {
          return NotFound();
        }
        else
        {
          throw;
        }
      }
      return StatusCode(HttpStatusCode.NoContent);
    }



  }
}
