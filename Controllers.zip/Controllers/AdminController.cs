using FindMyRoomWEbApi.BAL;
using FindMyRoomWEbApi.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace FindMyRoomWEbApi.Controllers
{
  public class AdminController : ApiController
  {
    private readonly AdminManager manager = new AdminManager();

    [HttpGet]
    [Route("api/demo")]
    public string demo()
    {
      return "demo123";
    }



    [Route("api/Admin/unverified")]                     // show unverified properties
    public IHttpActionResult GetUnVerifiedProperties()
    {
      try
      {
        return Ok(manager.Get_UnverifiedProperties());
      }
      catch (Exception)
      {

        return BadRequest();
      }
    }


    [Route("api/Admin/verified")]         // show verified property list
    public IHttpActionResult GetVerifiedProperties()
    {

      try
      {
        return Ok(manager.GetVerifiedProperties());
      }
      catch (Exception)
      {

        return BadRequest();
      }
    }



    [Route("api/Admin/owners")]         // show owners list
    public IHttpActionResult Getowners()
    {
      try
      {
        return Ok(manager.Getowners());
      }
      catch (Exception exc)
      {
        return BadRequest();
      }
    }



    [Route("api/Admin/users")]        // show users list
    public IHttpActionResult Getusers()
    {
      try
      {
        return Ok(manager.Getusers());
      }
      catch (Exception Exc)
      {
        return BadRequest();
      }

    }



    [Route("api/Admin/feedbacks")]            // show feedbacks
    public IHttpActionResult getFeedbacks()
    {
      try
      {

        return Ok(manager.GetFeedbackTables());
      }
      catch (Exception ex)
      {
        return BadRequest();
      }

    }



    [HttpPost]
    [Route("api/Admin/verify")]       // verify a property

    public IHttpActionResult VerifyProperty(Admin_ListVerifiedProperties_Result prop)
    {
      Property property = manager.findPropertyByID(prop.PropertyId);

      if (property == null)
      {
        return NotFound();
      }

      try
      {
        if (manager.VerifyProperty(prop.PropertyId))
        {
          return Ok(property);
        }
      }
      catch (Exception)
      {

        return BadRequest();
      }
      return NotFound();

    }
  }
}
