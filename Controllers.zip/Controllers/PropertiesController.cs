using FindMyRoomWEbApi.BAL;
using FindMyRoomWEbApi.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace FindMyRoomWEbApi.Controllers
{
  public class PropertiesController : ApiController
  {
    readonly PropertyManager propertyManager = new BAL.PropertyManager();

    [HttpPost]                                      // Post a property
    public async Task<IHttpActionResult> PostPropertyAsync([FromBody] PropertyRegistration propertyRegistration)
    {   
      try
      {
        return Ok(await propertyManager.PostPropertyBAL(propertyRegistration));
      }
      catch (Exception)
      {

        return BadRequest();
      }
    }



    [HttpPut]
    public async Task<IHttpActionResult> UpdatePropertyAsync(PropertyUpdation details)    // Update Property Details
    {

      try
      {
        return Ok(await propertyManager.UpdatePropertyBAL(details));
      }
      catch (Exception)
      {
        return BadRequest();
      }
    }



    [HttpGet]
    [Route("api/Properties/GetPropertyByUsr")]
    public IHttpActionResult GetListOfPropByUser(int UserId)   // Fetch property list for perticular User
    {
      try
      {
        return Ok(propertyManager.GetListofPropertyUser(UserId).ToList<List_of_Properties_By_User_Result>());
      }
      catch (Exception)
      {

        return BadRequest();
      }
    }


    [HttpGet]
    [Route("api/Properties/getproperty")]
    public IHttpActionResult GetProperty(int id)        // Fetc property details bu ID
    {
      try
      {
        return Ok(propertyManager.GetPropertyBAL(id));
      }
      catch (Exception)
      {

        return BadRequest();
      }
    }

  }
}
