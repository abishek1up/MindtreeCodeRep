  using FindMyRoomWEbApi.BAL;
  using FindMyRoomWEbApi.Entity;
  using System;
  using System.Collections.Generic;
  using System.Linq;
  using System.Net;
  using System.Net.Http;
  using System.Web.Http;

  namespace FindMyRoomWEbApi.Controllers
  {
    public class PropertyDetailsController : ApiController
    {

      private readonly PropertyManager propertymanager = new PropertyManager();


      // GET: api/PropertyDeatils
      [HttpGet]
      [Route("api/PropertyDetails/getcities")]
      public IHttpActionResult GetCity()                            // Get cities/locations list
      { 
        try
        {
          List<City> citydetail = propertymanager.GetDetails().ToList();
          return Ok(citydetail);
        }
        catch (Exception)
        {

          return BadRequest();
        }
      }



      [HttpGet]
      [Route("api/PropertyDetails/showlist")]     ////   api/PropertyDetails/showList?id=1
      public IHttpActionResult GetProperties(string city)         // Get List of properties of a location/ city
      {
        try
        {
          return Ok(propertymanager.GetPropertyList(city).ToList());
        }
        catch (Exception)
        {

          return BadRequest();
        }

      }


      [HttpGet]                                                     // Get property details by id
      public IHttpActionResult GetSingleProperty(int id)    //   api/PropertyDetails/GetSingleProperty?id=1
      {                           
        try
        {
          List<User_PropertyDetails_Result> x = propertymanager.FindProperty(id).ToList();
          return Ok(x[0]);
        }
        catch (Exception)
        {

          return BadRequest();
        }
      }

    }
  }
