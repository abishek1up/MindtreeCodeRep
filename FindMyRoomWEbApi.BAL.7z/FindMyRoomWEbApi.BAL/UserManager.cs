using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using FindMyRoomWEbApi.DAL;
using FindMyRoomWEbApi.Entity;


namespace FindMyRoomWEbApi.BAL
{
  public class UserManager
  {
    private readonly UserAccessor userAccessor = new UserAccessor();
    public async Task<int> SaveUserDetails(User user)
    {
      byte[] encode = new byte[user.password.Length];

      encode = Encoding.UTF8.GetBytes(user.password);
      user.password = Convert.ToBase64String(encode);

      try
      {
        return await userAccessor.SaveUserDetails(user);
      }

      catch (Exception e)
      {
        throw new Exception(e.Message);
      }
    }
    public async Task<int> verifyEmailB(String email)
    {
      return await userAccessor.verifyEmailD(email);

    }
    public async Task<int> verifyPhoneB(String phone)
    {
      return await userAccessor.verifyPhoneD(phone);

    }
    public async Task<string> CheckRefferalCode(string r_code)
    {
      return await userAccessor.CheckRefferalCode(r_code);
    }



    //-------------uma-------------------------

    string otp;

    public async Task<int> verifyMailBAL(string mail)
    {
      return await userAccessor.verifyMailDAL(mail);
    }
    public async Task<string> generateOTPBAL(string mail)
    {
      string num = "0123456789";
      int len = num.Length;
      otp = string.Empty;
      int otpdigit = 4;
      string finaldigit;
      int getindex;
      for (int i = 0; i < otpdigit; i++)
      {
        do
        {
          getindex = new Random().Next(0, len);
          finaldigit = num.ToCharArray()[getindex].ToString();
        } while (otp.IndexOf(finaldigit) != -1);
        otp += finaldigit;
      }
      SendMail(mail);
      return otp;

    }
    public async Task SendMail(string mail)
    {
      try
      {
        string fromaddr = "findmyroom2018@gmail.com"; // Our official address
        string password = "Find#MyRoom2018";           // and password
        string toaddr = mail; //TO ADDRESS HERE
        MailMessage msg = new MailMessage();
        msg.Subject = " OTP for changing password FindMyRoom !!!";
        msg.From = new MailAddress(fromaddr);
        msg.Body = "Your OTP : " + otp + "\n\n\n Ignore This mail if you have'nt requested for changing password ! \n\n  - Admin \n (FindMyRoom) ";
        msg.To.Add(new MailAddress(toaddr));
        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.gmail.com";
        smtp.Port = 587;
        smtp.UseDefaultCredentials = false;
        smtp.EnableSsl = true;
        NetworkCredential nc = new NetworkCredential(fromaddr, password);
        smtp.Credentials = nc;
        smtp.Send(msg);

        //Console.WriteLine("Mail Sent Successfully !");
        //Console.ReadKey();
      }
      catch (Exception ex)
      {
        Console.WriteLine("Error in sending message :  " + ex.Message);
        Console.ReadKey();

      }

    }




    public async Task<int> updatePasswordBAL(string mail, string newPassword)
    {
      
      string sSignature = string.Empty;
      byte[] encode = new byte[newPassword.Length];
      encode = Encoding.UTF8.GetBytes(newPassword);
      sSignature = Convert.ToBase64String(encode);
      try
      {
        return await userAccessor.updatePasswordDAL(mail, sSignature);
      }
      catch (Exception e)
      {
        throw new Exception(e.Message);
      }
    }



    public async Task<int> confirmPasswordBAL(string mail, string oldPassword)
    {
      string dBPassword = await userAccessor.confirmPasswordDAL(mail);
      string decryptpwd = string.Empty;
      UTF8Encoding encodepwd = new UTF8Encoding();
      Decoder Decode = encodepwd.GetDecoder();
      byte[] todecode_byte = Convert.FromBase64String(dBPassword);
      int charCount = Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
      char[] decoded_char = new char[charCount];
      Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
      decryptpwd = new String(decoded_char);
      if (decryptpwd == oldPassword)
        return 1;
      else
        return 0;
    }



    public User GetUserById(int id)
    {

      return userAccessor.getUserbyId(id);

    }




    // verifying username and password

    public LoginCheck LoginCheckBusinessLogic(String id)
    {
      LoginCheck Check = new LoginCheck();
      Check.isValid = false;
      String[] s = id.Split(':');
      string Email = s[0];
      string Password = s[1];
      byte[] encode = new byte[Password.Length];
        encode = Encoding.UTF8.GetBytes(Password);
        Password = Convert.ToBase64String(encode);
        List<User> UserListDetails = userAccessor.LoginCheckDataAccess();
        foreach (User U in UserListDetails)
        {
          if ((Email.Trim() == U.email.Trim()) && (Password.Trim() == U.password.Trim()))
          {
            Check.isValid = true;
            Check.userEmailID = U.email;
            Check.userID = U.UserId;
            UInt64 hashedValue = 3074457345618782421ul;
            for (int i = 0; i < Email.Length; i++)
            {
              hashedValue += Email[i];
              hashedValue *= 3074457345618258799ul;
            }
            Check.tokenString = hashedValue.ToString();
            break;
          }
        
      }
      return Check;
    }

    public bool UserExists (int uid)
    {
      return userAccessor.UserExists(uid);
    }


  }
}
