using FindMyRoomWEbApi.DAL;
using FindMyRoomWEbApi.Entity;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FindMyRoomWEbApi.BAL
{
    public class PropertyManager
    {
        private readonly PropertyAccessor propertyAccessor = new PropertyAccessor();
        
        public List<City> GetDetails()
        {
            List<City> finalLocations = propertyAccessor.GetCities();
            List<Location> tempLocations = propertyAccessor.GetLocation();

            foreach (Location loc in tempLocations)                 //Combining Cities with Loactions
            {
                City tempCity = new City();
                tempCity.CityId = Convert.ToInt32(loc.CityId);
                tempCity.City_name = loc.Location_name;
                finalLocations.Add(tempCity);
            }
            return finalLocations;
        }


        public List<List_of_Properties_Result> GetPropertyList(string city)     //listing properties on location
        {
            return propertyAccessor.GetPropertyList(city);
        }


        public ObjectResult<User_PropertyDetails_Result> FindProperty(int id)  // get details by propid
        {
            return propertyAccessor.FindPropertydetails(id);
        }


        

        public async Task<int> PostPropertyBAL(PropertyRegistration propertyRegistration)  // register property
        {
            return await propertyAccessor.PostPropertyDAL(propertyRegistration);
        }


        public async Task<int> UpdatePropertyBAL(PropertyUpdation details)  // update -- not in use
        {
            return await propertyAccessor.UpdatePropertyDAL(details);
        }


        public List<User_PropertyDetails_Result> GetPropertyBAL(int id)
        {
            return propertyAccessor.GetPropertyDAL(id);
        }

        public List<List_of_Properties_By_User_Result> GetListofPropertyUser(int UserId)
        {
          return propertyAccessor.GetListOfPropertiesByUser(UserId);
        }


  }
}
