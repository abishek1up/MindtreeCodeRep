using FindMyRoomWEbApi.DAL;
using FindMyRoomWEbApi.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FindMyRoomWEbApi.BAL
{
   public  class AdminManager
    {
        readonly AdminAccessor accessor = new AdminAccessor();
        public List<Admin_ListUnVerifiedProperties_Result> Get_UnverifiedProperties()
        {
            return accessor.Get_UnverifiedProperties();
        }

        public List<FeedbackTable> GetFeedbackTables()
        {
            return accessor.GetFeedbacks();
        }

        public List<Admin_ListVerifiedProperties_Result> GetVerifiedProperties()
        {
            return accessor.GetVerifiedProperties();
        }

        public List<Admin_OwnerDetails_Result> Getowners()
        {
            return accessor.Getowners();
        }

        public List<Admin_UsersList_Result> Getusers()
        {
            return accessor.Getusers();
        }

        public bool VerifyProperty(int? id)
        {
            try
            {
                return accessor.VerifyProperty(id);
            }
            catch (Exception)
            {

                throw new Exception("");
            }
        }


        public Property findPropertyByID(int propertyID)
        {
            return accessor.findProperty(propertyID);
        }

    }
}
